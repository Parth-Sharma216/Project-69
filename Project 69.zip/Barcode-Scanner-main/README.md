# Barcode-Scanner
** Should have .expo and .expo-shared in the folder along with node modules to have the project executed.
